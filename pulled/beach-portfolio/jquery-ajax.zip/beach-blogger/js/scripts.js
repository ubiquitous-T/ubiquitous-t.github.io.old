// form input
var $inputEl = $(".user-data");
// search button
var $buttonEl = $(".search-btn");
// element to hold results
var $resultEl = $(".search-results");
// user id to be searched
var userId;

// capture input when focus is lost
$inputEl.on("focusout", function(event) {
  userId = $(this).val().trim();

});
// bind click event on button
$buttonEl.on("click", function() {
  //console.log(userId);
  $.ajax({url:"http://jsonplaceholder.typicode.com/posts?userId=" + userId})
  .success(function(data) {
    $($resultEl).append("<p><b>userId: "+userId+" </b></p>");
    for (var i = 0; i < data.length; i++) {
      // array json objects
      console.log(data[i]);
      var html = "<div><span><b>id: </b> "+data[i].id+"</span><p><b>title: </b> "+data[i].title+"</p><p><b>body: </b> "+data[i].body+"</p></div><br>";

      $($resultEl).append(html);
    }
  });
  //console.log(result);
});
